﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass20
{
    public class MyCustomQueue<T>
    {

        // Construtors

        // Methods
        public void Enqueue(T item)
        {
            if ((Head is null) && (Count == 0))
            {
                Head = Tail = new ListNode<T>(item);
                Tail.PreviousNode = null;
                Head.NextNode = null;
                count++;
            }
            else if ((Head == Tail) && (Count == 1))
            {
                var temp = Head;
                var temp2 = Tail.PreviousNode = Head.NextNode;
                var newNode = new ListNode<T>(item, temp2, temp);
                Head = newNode;
                Tail.PreviousNode = Head;
                Head.NextNode = Tail;
                count++;
            }
            else if (Count == 2)
            {
                var temp = Head;
                var temp2 = Head.NextNode;
                var temp3 = Tail.PreviousNode;
                var temp4 = Head.PreviousNode = null;
                var newNode = new ListNode<T>(item, temp4, temp);
                Head = newNode;
                Head.PreviousNode = Head;
                Head.NextNode = temp;
                Tail.PreviousNode = Head.NextNode;
                count++;
            }
            else if (Count > 2)
            {
                var temp = Head;
                var temp2 = Head.NextNode;
                var temp4 = Head.PreviousNode = null;
                var newNode = new ListNode<T>(item, temp4, temp);
                Head = newNode;
                Head.PreviousNode = Head;
                Head.NextNode = temp;
                count++;
            }
        }
        public T Dequeue()
        {
            if (Head is null)
            {
                throw new InvalidOperationException("This stack is empty");
                return default;
            }
            else if (Head == Tail)
            {
                var temp = Head.Value;
                Head = Tail = null;
                count = 0;
                return temp;
            }
            else
            {
                var temp = Tail.PreviousNode;
                var temp2 = Tail.Value;
                Tail = null;
                Tail = temp;
                count--;
                return temp2;
            }
        }
        // Properties
        public ListNode<T> Head { get; set; }
        public ListNode<T> Tail { get; set; }
        private int count;

        public int Count
        {
            get
            {
                return this.count;
            }
        }
    }
}
