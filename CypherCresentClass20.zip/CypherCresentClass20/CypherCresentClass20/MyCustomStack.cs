﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass20
{
    public class MyCustomStack<T>
    {
        // Construtors

        // Methods

        public void Puch(T item)
        {
            if (Head is null)
            {
                Head = Tail = new ListNode<T>(item);
                count++;
            }
            else
            {
                var temp = Head;
                var newNode = new ListNode<T>(item, null, temp);
                Head = newNode;
                count++;
            }
        }
        public T Pop()
        {
            if (Head is null)
            {
                throw new InvalidOperationException("This stack is empty");
                return default;
            }
            else if (Head == Tail)
            {
                var temp = Head.Value;
                Head = Tail = null;
                count = 0;
                return temp;
            }
            else
            {
                var temp = Head.NextNode;
                var temp2 = Head.Value;
                Head = null;
                Head = temp;
                count--;
                return temp2;
            }
        }
        public T Peek()
        {
            if (Head is null)
            {
                throw new InvalidOperationException("This stack is empty");
            }
            else
            {
                var temp = Head.Value;
                return temp;
            }
        }
        // Properties
        public ListNode<T> Head { get; set; }
        public ListNode<T> Tail { get; set; }
        private int count;

        public int Count
        {
            get
            {
                return this.count;
            }
        }
    }
}
