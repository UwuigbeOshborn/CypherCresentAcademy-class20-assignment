﻿// See https://aka.ms/new-console-template for more information
using CypherCresentClass20;

Console.WriteLine("--------------   Question 1    --------------");
MyCustomStack<int> stack = new MyCustomStack<int>();
stack.Puch(1);
stack.Puch(2);
stack.Puch(3);
stack.Puch(12);
stack.Puch(5);
stack.Puch(7);

int item2 = stack.Peek();
Console.WriteLine($"The top item in the stack = {item2}");

while (stack.Count > 0)
{
    Console.WriteLine($"{stack.Count}");
    int item = stack.Pop();
    Console.WriteLine($"   = {item}");
}
stack.Pop();
//stack.Peek();


Console.WriteLine("--------------   Question 2    --------------");
MyCustomQueue<int> queue = new MyCustomQueue<int>();
queue.Enqueue(1);
queue.Enqueue(2);
//queue.Enqueue(3);
//queue.Enqueue(4);
//queue.Enqueue(5);
//queue.Enqueue(6);

while (queue.Count > 0)
{
    Console.WriteLine($"{queue.Count}");
    int item3 = queue.Dequeue();
    Console.WriteLine($"   = {item3}");
}